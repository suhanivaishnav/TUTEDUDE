from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
import time

EMAIL = "vaishnavsuhani2004@gmail.com"
PASSWORD = "Suhani2004@"
POST_TEXT = "This post is automated using Selenium & Python!"

options = webdriver.ChromeOptions()
options.add_argument("--start-maximized")

driver = webdriver.Chrome(options=options)
wait = WebDriverWait(driver, 600)

# Open Facebook
driver.get("https://www.facebook.com/")

# Login
wait.until(EC.presence_of_element_located((By.ID, "email"))).send_keys(EMAIL)
driver.find_element(By.ID, "pass").send_keys(PASSWORD + Keys.RETURN)

# Wait for home feed
time.sleep(12)

# 👉 STEP 1: Click "What's on your mind?" button (safe way)
create_post = wait.until(
    EC.element_to_be_clickable((
        By.XPATH,
        "//span[contains(text(),'mind') or contains(text(),'on your mind')]/ancestor::div[@role='button']"
    ))
)
driver.execute_script("arguments[0].click();", create_post)

# 👉 STEP 2: Wait for ACTIVE textbox (this is the key fix)
post_box = wait.until(
    EC.visibility_of_element_located((
        By.XPATH,
        "//div[@role='textbox' and @contenteditable='true']"
    ))
)

post_box.send_keys(POST_TEXT)
time.sleep(3)

# 👉 STEP 3: Click Post button (multiple fallbacks)
try:
    post_button = wait.until(
        EC.element_to_be_clickable((By.XPATH, "//div[@aria-label='Post']"))
    )
except:
    post_button = wait.until(
        EC.element_to_be_clickable((By.XPATH, "//span[text()='Post']/ancestor::div[@role='button']"))
    )

driver.execute_script("arguments[0].click();", post_button)

time.sleep(5)
driver.quit()
